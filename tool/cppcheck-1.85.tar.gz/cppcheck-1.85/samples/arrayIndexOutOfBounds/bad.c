int main()
{
    int a[2];
    a[0] = 0;
    a[1] = 0;
    a[2] = 0;
    return a[0];
}
